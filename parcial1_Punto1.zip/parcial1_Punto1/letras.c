#include <ctype.h>
#include "letras.h"

// devuelve la mayuscula de la letra  que se le pasa
char aMayuscula(char a) {    
    return toupper(a);
}

// devuelve la minuscula de la letra  que se le pasa
char aMinuscula(char a) {    
    return tolower(a);
}
