char aMayuscula(char a);
char aMinuscula(char a);