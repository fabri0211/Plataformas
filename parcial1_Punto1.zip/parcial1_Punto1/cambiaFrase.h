int cambiaMinuscula(char palabra[]);
int cambiaMayuscula(char palabra[]);