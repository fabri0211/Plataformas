#include "letras.h"
#include <stdio.h>
#define MAX_PALABRA 50

int cambiaMinuscula(char palabra[]) {
    int j = 0;
    char ch;
 
    while (palabra[j]) {
        ch = palabra[j];
        printf("%c", aMinuscula(ch));
        j++;
    }

    return j;
}

int cambiaMayuscula(char palabra[]) {
    int j = 0;
    char ch;
 
    while (palabra[j]) {
        ch = palabra[j];
        printf("%c", aMayuscula(ch));
        j++;
    }

    return j;
}