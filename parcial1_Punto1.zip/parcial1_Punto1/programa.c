#include <stdio.h>
#define MAX_PALABRA 50
#include "cambiaFrase.h"

int main(int argc, char *argv[]) {

    char palabra[MAX_PALABRA];
    int opcion;

    printf("Introduce una palabra: ");
    scanf("%s", palabra);

    printf("\nEscribe 1 para pasar a mayusculas, y 2 para pasar a minusculas:");
    fflush(stdin);
    scanf("%d", &opcion);

    printf("Palabra cambiada (%d):\n", opcion);

    if(opcion == 1) {
        int n = cambiaMayuscula(palabra);
        printf("\nLetras cambiadas: %d", n);
    } else if (opcion == 2) {
        int n = cambiaMinuscula(palabra);
        printf("\nLetras cambiadas: %d", n);
    }else {
        printf("Opcion invalida");
    }

}